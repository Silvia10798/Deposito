package cuentas;

/**
 * La clase CCuenta representa una cuenta bancaria con nombre, número de cuenta, saldo y tipo de interés. 
 */
public class CCuenta {


    private String nombre; //Nombre del titular de la cuenta.
    private String cuenta; //Número de cuenta.
    private double saldo; //Saldo actual de la cuenta.
    private double tipoInterés; //Tipo de interés de la cuenta.

    /**
     * Contructor por defecto de la clase CCuenta.
     * Crea un nuevo objeto de CCuenta con valores predeterminados.
     */
    public CCuenta()
    {
    }

    /**
     * Constructor con parámetros de la clase CCuenta.
     * Cre un nuevo objeto de CCuenta con los valores predeterminados.
     * @param nom es el nombre del titular de la cuenta.
     * @param cue es el número de cuenta.
     * @param sal es el saldo inicial de la cuenta.
     * @param tipo es el tipo de interés de la cuenta.
     */
    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        nombre =nom;
        cuenta=cue;
        saldo=sal;
    }

    /**
     * Es el método que devuelve el saldo actual de la cuenta.
     * @return es el saldo actual de la cuenta.
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * Es el método que establece el saldo de la cuenta.
     * @param saldo es el nuevo saldo de la cuenta.
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * Es el método que devuelve el nombre del titular de la cuenta.
     * @return es el nombre del titular de la cuenta.
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * Es el método que establece el nombre del titular de la cuenta.
     * @param nombre es el nuevo nombre del titular de la cuenta.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Es el método que devuelve el número de cuenta.
     * @return es el número de cuenta.
     */
    public String getCuenta() {
        return cuenta;
    }

    /**
     * Es el método que establece el número de cuenta.
     * @param cuenta es el nuevo número de cuenta.
     */
    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    /**
     * Es el método que devuelve el tipo de interés de la cuenta.
     * @return es el tipo de interés de la cuenta.
     */
    public double getTipoInterés() {
        return tipoInterés;
    }

    /**
     * Es el método que establece el tipo de interés de la cuenta.
     * @param tipoInterés es el nuevo tipo de interés de la cuenta.
     */
    public void setTipoInterés(double tipoInterés) {
        this.tipoInterés = tipoInterés;
    }
    
    /**
     * Es el método que devuelve el saldo actual de la cuenta.
     * @return es el saldo actual de la cuenta.
     */
    public double estado()
    {
        return saldo;
    }

    /**
     * Es el método que realiza un ingreso en la cuenta.
     * @param cantidad es la cantidad que se ingresa en la cuenta.
     * @throws Exception si la cantidad fuese negativa.
     */
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        saldo = saldo + cantidad;
    }

    /**
     * Es el método que realiza una retirada de dinero de la cuenta.
     * @param cantidad es la cantidad que se retira de la cuenta.
     * @throws Exception si la cantidad fuese negativa o si hay menos dinero de que se quiere retirar.
     */
    public void retirar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No se hay suficiente saldo");
        saldo = saldo - cantidad;
    }
}
